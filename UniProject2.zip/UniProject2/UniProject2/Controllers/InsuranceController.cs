﻿using BusLay.Extentions;
using BusLay.Forms;
using BusLay.Services;
using BusLay.View;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace UniProject2.Api
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class InsuranceController : ControllerBase
    {
        private readonly InsuranceService insuranceService;
        private readonly IHttpContextAccessor accessor;
        public InsuranceController(InsuranceService insuranceService, IHttpContextAccessor accessor)
        {
            this.insuranceService = insuranceService;
            this.accessor = accessor;
        }

        [HttpGet]
        [AllowAnonymous]
        [Route("get-all")]
        public ActionResult<List<InsuranceView>> GetAll()
        {
            return insuranceService.GetAll().Select(a => a.ToView()).ToList();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [Route("add")]
        public ActionResult<InsuranceView> AddInsurance([FromBody] InsuranceForm form)
        {
            return insuranceService.AddInsurance(form);
        }

        [HttpDelete]
        [Authorize(Roles = "Admin")]
        [Route("remove/{int:id}")]
        public IActionResult RemoveInsurance([FromQuery] int id)
        {
            insuranceService.Remove(id);
            return Ok();
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        [Route("get-insurance/{int:id}")]
        public ActionResult<InsuranceView> GetInsurance([FromQuery] int id)
        {
            return insuranceService.GetInsurance(id);
        }

        [HttpPut]
        [Authorize(Roles = "Admin")]
        [Route("change")]
        public ActionResult<InsuranceView> Change([FromBody] InsuranceForm form)
        {
            return insuranceService.ChangeInsuranse(form);
        }

        [HttpGet]
        [Route("by-max-price/{double:price}")]
        public ActionResult<List<InsuranceView>> GetByMaxPrice([FromQuery] double price)
        {
            return insuranceService.GetByMaxPrice(price);
        }

        [HttpGet]
        [Route("by-min-price/{double:price}")]
        public ActionResult<List<InsuranceView>> GetByMinPrice([FromQuery] double price)
        {
            return insuranceService.GetByMinPrice(price);
        }

        [HttpGet]
        [Route("by-type/{string:type}")]
        public ActionResult<List<InsuranceView>> GetByInsurType([FromQuery] string type)
        {
            return insuranceService.GetByInsurType(type);
        }
    }
}
