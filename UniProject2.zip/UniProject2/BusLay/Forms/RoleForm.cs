﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusLay.Forms
{
    public class RoleForm
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
