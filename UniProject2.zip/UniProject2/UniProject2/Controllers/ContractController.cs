﻿using BusLay.Extentions;
using BusLay.Forms;
using BusLay.Services;
using BusLay.View;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace UniProject2.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContractController : ControllerBase
    {
        private readonly IHttpContextAccessor accessor;
        private readonly ContractService contractService;
        public ContractController(ContractService contractService, IHttpContextAccessor accessor)
        {
            this.contractService = contractService;
            this.accessor = accessor;
        }

        [HttpPost]
        [Route("create")]
        [Authorize(Roles = "Admin")]
        public ActionResult<ContractView> CreateContract([FromBody] ContractForm form)
        {
            return contractService.CreateContract(form);
        }

        [HttpPut]
        [Authorize(Roles = "Admin")]
        [Route("change")]
        public ActionResult<ContractView> ChangeContract([FromBody] ContractForm form)
        {
            return contractService.Change(form).ToView();
        }

        [HttpDelete]
        [Authorize(Roles = "Admin")]
        [Route("remove/{int:id}")]
        public IActionResult RemoveContract([FromQuery] int id)
        {
            contractService.RemoveContract(id);
            return Ok();
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        [Route("get-all")]
        public ActionResult<List<ContractView>> GetAll()
        {
            return contractService.GetAllAsync().Result;
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        [Route("max-price/{double:price}")]
        public ActionResult<List<ContractView>> ByMaxPrice([FromBody] double price)
        {
            return contractService.GetByMaxPrice(price);
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        [Route("min-price/{double:price}")]
        public ActionResult<List<ContractView>> ByMinPrice([FromBody] double price)
        {
            return contractService.GetByMinPrice(price);
        }

        [HttpGet]
        [Authorize]
        [Route("current-customer-contracts")]
        public ActionResult<List<ContractView>> CurrentCustomerContracts()
        {
            var customerId = int.Parse(accessor.HttpContext.User.FindFirst("Id").Value);
            return contractService.GetCurrentContract(customerId);
        }

        [HttpPut]
        [Authorize]
        [Route("contract/add-insto-contract")]
        public ActionResult<AddedInsView> AddInsuranceToContract([FromBody] ContractInsuranceForm form)
        {
            return contractService.AddInsToContract(form);
        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        [Route("get-contract/{int:id}")]
        public ActionResult<ContractView> GetContract([FromQuery] int id)
        {
            return contractService.GetContract(id);
        }
    }
}
