﻿using BusLay.View;

namespace BusLay.Forms
{
    public class AddedInsView
    {
        public double Price { get; set; }
        public InsuranceView InsuranceView { get; set; }
    }
}
