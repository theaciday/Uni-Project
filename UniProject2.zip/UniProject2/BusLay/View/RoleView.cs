﻿namespace BusLay.View
{
    public class RoleView
    {
        public int Id { get; set; }
        public string RoleName { get; set; }
    }
}
