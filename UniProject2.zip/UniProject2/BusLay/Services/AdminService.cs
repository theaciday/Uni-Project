﻿using BusLay.Context;
using BusLay.Extentions;
using BusLay.Forms;
using BusLay.View;
using DAL.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BusLay.Services
{
    public class AdminService
    {
        private readonly IPasswordHasher<object> hasher;
        private readonly DataContext context;
        public AdminService(DataContext context)
        {
            this.context = context;
            hasher = new PasswordHasher<object>();
        }

        public void Remove(int customerId)
        {
            var customer = context.Customers.FirstOrDefault(c => c.Id == customerId);
            context.Customers.Remove(customer);
        }

        public List<CustomerView> GetAll() => context.Customers.AsQueryable().Include(a => a.Roles).Select(c => c.ToView()).ToList();


        public Customer Change(ChangeCustomerForm form)
        {
            try
            {
                var acc = context.Customers.Include(a => a.Roles).FirstOrDefault(acc => acc.Id == form.Id);
                if (form.FirstName.Length != 0)
                {
                    acc.FirstName = form.FirstName;
                }
                if (form.LastName.Length != 0)
                {
                    acc.LastName = form.LastName;

                }
                if (form.Username.Length != 0)
                {
                    acc.Username = form.Username;
                }

                if (form.IdRoles.Count != 0)
                {
                    var roles = context.Roles.Where(x => form.IdRoles.Contains(x.Id)).ToList();
                    acc.Roles = roles;
                }

                var result = context.SaveChanges();
                return acc;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public CustomerView GetCustomer(int id)
        {
            return context.Customers.FirstOrDefault(c => c.Id == id).ToView();
        }

        public Customer Create(CustomerForm form)
        {
            var entry = context.Customers.Add(new Customer
            {
                Password = hasher.HashPassword(null, form.Password),
                DOB = form.DOB,
                FirstName = form.FirstName,
                LastName = form.LastName,
                Rating = form.Rating,
                Username = form.UserName
            });
            var roles = context.Roles.Where(x => form.Roles.Contains(x.Name.Trim().ToLower())).ToList();
            if (roles.Any())
            {
                entry.Entity.Roles = roles;
            }
            context.SaveChanges();
            return entry.Entity;
        }
    }
}
