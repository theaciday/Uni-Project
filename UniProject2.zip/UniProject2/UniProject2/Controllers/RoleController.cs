﻿using BusLay.Extentions;
using BusLay.Forms;
using BusLay.Services;
using BusLay.View;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace UniProject2.Api
{
    [Route("api")]
    [ApiController]
    public class RoleController : ControllerBase
    {

        private readonly RoleService roleService;

        public RoleController(RoleService roleService)
        {
            this.roleService = roleService;
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        [Route("roles")]
        public ActionResult<List<RoleView>> AllRoles()
        {
            return roleService.GetRoles().Select(x => x.ToView()).ToList();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [Route("create-role")]
        public ActionResult<RoleView> AddRole([FromBody] RoleForm form)
        {
            return roleService.AddRole(form).ToView();
        }

        [HttpPut]
        [Authorize(Roles = "Admin")]
        [Route("change-role")]
        public ActionResult<RoleView> ChangeRole([FromBody] RoleForm form)
        {
            return roleService.ChangeRole(form);
        }

        [HttpDelete]
        [Authorize(Roles = "Admin")]
        [Route("role-remove/{int:id}")]
        public IActionResult RemoveRole([FromQuery] int id)
        {
            roleService.RemoveRole(id);
            return Ok();
        }

    }
}
