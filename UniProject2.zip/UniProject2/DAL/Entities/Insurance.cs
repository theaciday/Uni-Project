﻿namespace DAL.Entities
{
    public class Insurance
    {
        public int Id { get; set; }

        public string InsurName { get; set; }

        public string InsurType { get; set; }

        public double Price { get; set; }

        public Contract Contract { get; set; }//Договор
    }
}
