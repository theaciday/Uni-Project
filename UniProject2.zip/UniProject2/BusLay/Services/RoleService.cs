﻿using BusLay.Context;
using BusLay.Extentions;
using BusLay.Forms;
using BusLay.View;
using DAL.Entities;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusLay.Services
{
    public class RoleService
    {
        private readonly DataContext dbContext;
        public RoleService(DataContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public Role AddRole(RoleForm roleForm)
        {
            var newRole = dbContext.Roles.Add(new Role
            {
                Name = roleForm.RoleName,
            });
            return newRole.Entity;
        }

        public List<Role> GetRoles()
        {
            var roles = dbContext.Roles.AsQueryable().ToList();
            return roles;
        }

        public RoleView ChangeRole(RoleForm form)
        {
            var role = dbContext.Roles.FirstOrDefault(r => r.Id == form.RoleId);
            role.Name = form.RoleName;
            dbContext.Roles.Update(role);
            dbContext.SaveChanges();
            return role.ToView();
        }

        public void RemoveRole(int roleId)
        {
            var role = dbContext.Roles.FirstOrDefault(r => r.Id == roleId);
            dbContext.Roles.Remove(role);
        }
    }
}
