﻿using BusLay.Extentions;
using BusLay.Forms;
using BusLay.Services;
using BusLay.View;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace UniProject2.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly CustomerService customerService;
        private readonly IHttpContextAccessor accessor;
        public CustomerController(CustomerService customerService, IHttpContextAccessor accessor)
        {
            this.customerService = customerService;
            this.accessor = accessor;
        }


        [Route("current")]
        [HttpGet]
        public async Task<ActionResult<CustomerView>> CurrentUserAsync()
        {
            var accId = int.Parse(accessor.HttpContext.User.FindFirst("Id").Value);
            var customer = await customerService.FindOneAsync(ac => ac.Id == accId);

            return customer.ToView();
        }

        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Registration([FromBody] RegisterForm form)
        {
            await customerService.RegisterAsync(form);
            return Ok();
        }

        [HttpGet]
        [Route("get-all")]
        public ActionResult<List<CustomerView>> GetAll()
        {
            return customerService.GetAll();
        }

        [HttpGet]
        [Route("get-by-rating")]
        public ActionResult<List<CustomerView>> GetByRating([FromBody] CustomerFindForm findForm)
        {
            return customerService.GetByRating(findForm);
        }

        [HttpGet]
        [Route("get-by-name/{string:name}")]
        public ActionResult<List<CustomerView>> GetByName([FromQuery] string name)
        {
            return customerService.GetByName(name);
        }


    }
}
