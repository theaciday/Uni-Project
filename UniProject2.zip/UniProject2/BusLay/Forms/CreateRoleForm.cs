﻿namespace BusLay.Forms
{
    public class CreateRoleForm
    {
        public string RoleName { get; set; }
    }
}
