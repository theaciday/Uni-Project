﻿namespace BusLay.Forms
{
    public class AuthForm
    {
        public string Password { get; set; }
        public string UserName { get; set; }
    }
}
