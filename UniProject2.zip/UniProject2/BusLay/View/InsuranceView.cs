﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusLay.View
{
    public class InsuranceView
    {
        public int Id { get; set; }
        public string InsurName { get; set; }
        public string InsurType { get; set; }
        public double Price { get; set; }
        public string Error { get; set; }

    }
}
