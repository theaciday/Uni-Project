﻿using BusLay.Extentions;
using BusLay.Forms;
using BusLay.Services;
using BusLay.View;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace UniProject2.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly AdminService adminService;
        private readonly IHttpContextAccessor accessor;
        public AdminController(AdminService adminService, IHttpContextAccessor accessor)
        {
            this.adminService = adminService;
            this.accessor = accessor;
        }

        [HttpDelete]
        [Authorize(Roles = "Admin")]
        [Route("delete/{int:id}")]
        public IActionResult DeleteCutomer([FromQuery] int customerId)
        {
            adminService.Remove(customerId);
            return Ok();
        }

        [HttpPut]
        [Authorize(Roles = "Admin")]
        [Route("change")]
        public ActionResult<CustomerView> ChangeCustomer([FromBody] ChangeCustomerForm form)
        {
            return adminService.Change(form).ToView();
        }
        [HttpGet]
        [Authorize(Roles = "Admin")]
        [Route("profile-cus")]
        public ActionResult<CustomerView> GetCustomer([FromBody] ChangeCustomerForm form)
        {
            return adminService.GetCustomer(form.Id);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [Route("admin/create-customer")]
        public ActionResult<CustomerView> CreateCustomer([FromBody] CustomerForm form)
        {
            return adminService.Create(form).ToView();
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        [Route("all-cutomers")]
        public ActionResult<List<CustomerView>> ListCustomers()
        {
            return adminService.GetAll();
        }
    }
}
