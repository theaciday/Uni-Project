﻿using System;

namespace BusLay.View
{
    public class TokensView
    {
        public string AccessToken { get; set; }
        public Guid RefreshToken { get; set; }

    }
}
