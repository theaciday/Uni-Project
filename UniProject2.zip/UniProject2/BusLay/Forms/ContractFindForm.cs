﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusLay.Forms
{
    public class ContractFindForm
    {
        public TimeSpan MaxDuration { get; set; }
        public TimeSpan MinDuration { get; set; }
        public double MaxFinalPice { get; set; }
        public double MinFinalPice { get; set; }

    }
}
