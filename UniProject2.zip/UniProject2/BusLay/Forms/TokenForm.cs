﻿using System;

namespace BusLay.Forms
{
    public class TokenForm
    {
        public Guid RefreshToken { get; set; }
    }
}
