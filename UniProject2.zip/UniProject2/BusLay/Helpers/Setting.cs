﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusLay.Settings
{
    public  class Setting
    {
        public string Secret { get; set; } = "marcy9d8534b48w951b9287d492b256x";
    }
}
