﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Net.Mime;
using System.Text.Json;

namespace Modules.Infrostructure
{
    public static class ErrorHandlerExtention
    {
        public static IApplicationBuilder UseApiExceptionHandler(this IApplicationBuilder builder, string prefix = null)
        {
            return builder.UseWhen(ctx => true, builder =>
            {
                builder.UseExceptionHandler(new ExceptionHandlerOptions()
                {
                    ExceptionHandlingPath = new PathString(prefix),
                    ExceptionHandler = async (context) =>
                    {
                        context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                        context.Response.ContentType = MediaTypeNames.Application.Json;
                        var feature = context.Features.Get<IExceptionHandlerFeature>();
                        var logger = context.RequestServices.GetService<ILogger<ExceptionHandlerMiddleware>>();

                        if (feature is not null)
                        {
                            var error = new
                            {
                                Message = "Internal Server Error",
                                StatusCode = StatusCodes.Status500InternalServerError
                            };
                            logger.LogError(feature.Error.Message, feature.Error);
                            await context.Response.WriteAsync(JsonSerializer.Serialize(error,
                                new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase }));
                        }
                    }
                });
            });

        }
    }
}
