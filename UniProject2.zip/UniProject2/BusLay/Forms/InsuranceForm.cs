﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusLay.Forms
{
    public class InsuranceForm
    {
        public int Id { get; set; }
        public string InsurName { get; set; }

        public string InsurType { get; set; }

        public double Price { get; set; }
      
    }
}
