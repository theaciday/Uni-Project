﻿namespace BusLay.View
{
    public class PriceView
    {
        public double Price { get; set; }
    }
}
