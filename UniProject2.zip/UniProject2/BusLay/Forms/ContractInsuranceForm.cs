﻿namespace BusLay.Forms
{
    public class ContractInsuranceForm
    {
        public int Id { get; set; }
        public string InsurName { get; set; }
        public string InsurType { get; set; }
        public double Price { get; set; }
        public int YearExp { get; set; }
        public int CustomerId { get; set; }

    }
}
