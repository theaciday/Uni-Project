﻿using BusLay.Context;
using BusLay.Extentions;
using BusLay.Forms;
using BusLay.View;
using DAL.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace BusLay.Services
{
    public class ContractService
    {
        private readonly DataContext dbContext;
        private readonly InsuranceService insuranceService;

        public ContractService(DataContext dbContext, InsuranceService insuranceService)
        {
            this.dbContext = dbContext;
            this.insuranceService = insuranceService;
        }

        public ContractView CreateContract(ContractForm form)
        {
            List<Insurance> insurances = new List<Insurance>();
            foreach (var item in form.InsurancesId)
            {
                insurances.Add(dbContext.Insuranses.FirstOrDefault(ins => ins.Id == item));
            }
            var time = DateTime.UtcNow;
            var duration = time - form.ValidityDate.ToDateTime();
            var newContract = dbContext.Contracts.Add(
                new Contract()
                {
                    CustomerId = form.CustomerId,
                    Details = form.Details,
                    FinalPrice = form.FinalPrice,
                    Duration = duration,
                    Insuranses = insurances,
                    SignUpDate = time,
                    ValidityDate = form.ValidityDate.ToDateTime(),
                });
            dbContext.SaveChanges();
            return newContract.Entity.ToView();
        }

        public List<ContractView> GetByMaxPrice(double price)
        {
            return dbContext.Contracts
                .Where(c => c.FinalPrice < price)
                .Select(a => a.ToView())
                .ToList();
        }

        public List<ContractView> GetByMinPrice(double price)
        {
            return dbContext.Contracts
                .Where(c => c.FinalPrice > price)
                .Select(a => a.ToView())
                .ToList();
        }

        public bool Any(Func<Contract, bool> p)
        {
            return dbContext.Contracts.Any(p);
        }

        public async Task<List<ContractView>> GetAllAsync()
        {
            return await Task.Run(() =>
            {
                var contracts = dbContext.Contracts.Where(c => c.Insuranses.Count != 0).Select(c => c.ToView()).ToList();
                return contracts;
            });
        }

        public List<ContractView> GetCurrentContract(int customerId)
        {
            return dbContext.Contracts
                .Where(c => c.CustomerId == customerId)
                .Select(a => a.ToView())
                .Include(a => a.Insuranses)
                .ToList();
        }

        public AddedInsView AddInsToContract(ContractInsuranceForm form)
        {
            var insurInfo = new AddedInsView();
            var insurance = dbContext.Insuranses.FirstOrDefault(s => s.Id == form.Id);
            var customer = dbContext.Customers.FirstOrDefault(c => c.Id == form.CustomerId);
            var contracts = dbContext.Contracts.Where(c => c.CustomerId == form.CustomerId).ToList();
            if (customer.Rating < 30)
            {
                insurInfo.Price = insurance.Price + ((insurance.Price / 100) * 10);
            }
            if (form.InsurType == "vehicle")
            {
                if (form.YearExp > 5)
                {
                    insurInfo.Price = insurance.Price - ((insurance.Price / 100) * 10);
                }
            }
            if (contracts.Count > 2)
            {
                insurInfo.Price = insurance.Price - ((insurance.Price / 100) * 8);
            }
            if (insurance.InsurType == "medical")
            {
                if (customer.Rating < 30)
                {
                    insurInfo.Price = insurance.Price + ((insurance.Price / 100) * 10);
                }
                if (customer.Rating > 60)
                {
                    insurInfo.Price = insurance.Price - ((insurance.Price / 100) * 8);
                }
            }
            if (insurance.InsurType == "property")
            {

                if (customer.Rating < 30)
                {
                    insurInfo.Price = insurance.Price + ((insurance.Price / 100) * 10);
                }
                if (customer.Rating > 60)
                {
                    insurInfo.Price = insurance.Price - ((insurance.Price / 100) * 8);
                }
            }
            if (form.InsurType == "finance")
            {

                if (customer.Rating < 30)
                {
                    insurInfo.Price = insurance.Price + ((insurance.Price / 100) * 10);
                }
                if (customer.Rating > 60)
                {
                    insurInfo.Price = insurance.Price - ((insurance.Price / 100) * 8);
                }
            }
            if (form.InsurType == "travel")
            {

                if (customer.Rating < 30)
                {
                    insurInfo.Price = insurance.Price + ((insurance.Price / 100) * 10);
                }
                if (customer.Rating > 60)
                {
                    insurInfo.Price = insurance.Price - ((insurance.Price / 100) * 8);
                }
            }
            insurInfo.InsuranceView = insurance.ToView();
            return insurInfo;
        }

        public ContractView GetContract(int id)
        {
            return dbContext.Contracts.FirstOrDefault(c => c.Id == id).ToView();
        }

        public async Task<Contract> FindOneAsync(Expression<Func<Contract, bool>> predicate = null)
        {
            return await Task.Run(() =>
            {
                return dbContext.Contracts.Where(predicate).Include(a => a.Insuranses).FirstOrDefaultAsync();
            });
        }

        public Contract Change(ContractForm form)
        {
            List<Insurance> insurances = new List<Insurance>();
            var contract = FindOneAsync(c => c.Id == form.Id);
            contract.Result.Details = form.Details.Length != 0 ? form.Details : contract.Result.Details;
            contract.Result.SignUpDate = DateTime.UtcNow;
            if (form.ValidityDate is not null)
            {
                var time = DateTime.UtcNow;
                contract.Result.Duration = time - form.ValidityDate.ToDateTime();
                contract.Result.ValidityDate = form.ValidityDate.ToDateTime();
            }
            if (form.FinalPrice != 0)
            {
                contract.Result.FinalPrice = form.FinalPrice;
            }
            if (form.InsurancesId is not null)
            {
                foreach (var item in form.InsurancesId)
                {
                    var insurance = insuranceService.FindOneAsync(a => a.Id == item);
                    insurances.Add(insurance.Result);
                }
                contract.Result.Insuranses = insurances;
            }
            dbContext.SaveChanges();
            return contract.Result;
        }

        public bool RemoveContract(int id)
        {
            var contract = dbContext.Contracts.FirstOrDefault(a => a.CustomerId == id);
            if (contract is null)
                return false;
            dbContext.Remove(contract);
            dbContext.SaveChanges();
            return true;
        }
    }
}
