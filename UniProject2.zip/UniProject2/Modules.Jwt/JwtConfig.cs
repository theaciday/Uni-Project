﻿namespace Modules.Jwt
{
    public class JwtConfig
    {
        public string Secret { get; set; }
    }
}